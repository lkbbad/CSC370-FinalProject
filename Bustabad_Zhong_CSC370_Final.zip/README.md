# CSC370-FinalProject
Final project for CSC370: Machine Reasoning (Jenny Zhong and Lindy Bustabad)

Implementations of GBFS, A*, and MCTS algorithms in solving Lights Out! game boards of size 2x2, 3x3, 4x4, and 5x5. 